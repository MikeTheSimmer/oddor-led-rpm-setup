#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <memory.h>
#include <libusb-1.0/libusb.h>

static libusb_context *context = NULL;
static libusb_device_handle *handle = NULL;
static libusb_device_handle *handles[0x10];

#define FRAMESIZE   768000   // 800x480x16bit
#define FRAMESIZE5  819840   // 854x480x16bit
#define MARGIN      0
#define MARGIN5     320

union axis{
    struct hx{
        unsigned char h:4;
        unsigned char u:2;
        unsigned char f:2;
    } x;

    struct hy{
        unsigned char h:4;
        unsigned char id:4;
    } y;

    char c;
};

struct point {
    union axis xh;
    unsigned char xl;
    union axis yh;
    unsigned char yl;

    unsigned char weight;
    unsigned char misc;
};

struct touch {
    unsigned char unused[2];
    unsigned char count;
    struct point p[2];
};

int get_version(libusb_device_handle *h)
{
    unsigned char buf[5] = {0x51, 0x02, 0x04, 0x1f, 0xfc};
    libusb_control_transfer(h, 0x40, 0xb5, 0, 0, buf, 5, 100);
    libusb_control_transfer(h, 0xc0, 0xb6, 0, 0, buf, 1, 100);
    libusb_control_transfer(h, 0xc0, 0xb7, 0, 0, buf, 5, 100);
    return ((int *)(buf + 1))[0];
}

void get_screen_version(libusb_device_handle *h, int *frame_size, int *margin, char *buf)
{
    switch (get_version(h)) {
    case 0x00000005:
        if (buf)
            sprintf(buf, "5inch, 480x854x16/24, SLM5.0-81FPC-A");
        if (frame_size)
            *frame_size = FRAMESIZE5;
        if (margin)
            *margin = MARGIN5;
        break;

    case 0x00000304:
        if (buf)
            sprintf(buf, "4.3inch, 480x800x16/24, D430FPC9316-A");
        if (frame_size)
            *frame_size = FRAMESIZE;
        if (margin)
            *margin = MARGIN;
        break;

    case 0x00000004:
        if (buf)
            sprintf(buf, "4inch, 480x800x16, TOSHIBA-2122");
        if (frame_size)
            *frame_size = FRAMESIZE;
        if (margin)
            *margin = MARGIN;
        break;

    case 0x00000104:
        if (buf)
            sprintf(buf, "4inch, 480x800x16/24, DJN-1922");
        if (frame_size)
            *frame_size = FRAMESIZE;
        if (margin)
            *margin = MARGIN;
        break;

    default:
        if (buf)
            sprintf(buf, "4inch/5inch, 480x800x16, default type");
        if (frame_size)
            *frame_size = FRAMESIZE;
        if (margin)
            *margin = MARGIN;
        break;
    }
}

int get_port_handle(uint16_t vid, uint16_t pid)
{
    struct libusb_device **list = NULL;
    int used = 0;

    int count = libusb_get_device_list(context, &list);
    for (int i = 0; i < count; i++) {
        struct libusb_device_descriptor desc;

        memset(&desc, 0, sizeof(struct libusb_device_descriptor));
        if (libusb_get_device_descriptor(list[i], &desc))
            continue;

        int curport = libusb_get_port_number(list[i]) - 1;
        if (desc.idVendor == vid && desc.idProduct == pid) {
            char screen_info[0x100] = {0};

            libusb_open(list[i], &handles[used]);

            libusb_claim_interface(handles[used], 0);
            libusb_set_interface_alt_setting(handles[used], 0, 0);

            get_screen_version(handles[used], NULL, NULL, screen_info);

            printf("Find screen at USB physics port %d\n", curport);
            printf("Type: %s\n", screen_info);

            used++;
        }
    }

    libusb_free_device_list(list, 0);
    return used;
}

int main(int argc, char *argv[])
{
    int frame_size = 0, margin = 0;

    if (argc > 2) {
        printf("send_frame [bmp16 data]\n");
        return 0;
    }


    // 1. find and open usb device.
    printf("Scaning for VoCore screen...\n\n");

    libusb_init(&context);
    int device_count = get_port_handle(0xc872, 0x1004);
    if (device_count == 0) {
        printf("No screen find, please check driver or USB cable.\n"
               "Press any key to exit.\n");
        getchar();      // avoid suddenly exit for windows.
        return -1;
    }

    handle = handles[0];
    printf("Detected %d screen(s), use first one for test.\n", device_count);

    // close rest screen handles.
    for (int i = 1; i < device_count; i++) {
        if (handles[i]) {
            libusb_release_interface(handles[i], 0);
            libusb_close(handles[i]);
        }
    }

    // we need this data to send correct frame.
    get_screen_version(handle, &frame_size, &margin, NULL);



    // 2. initialize screen and show frame.
    // quit sleep mode, or it will show white screen as default.
    uint8_t cmd1[] = {0x00, 0x29};
    libusb_control_transfer(handle, 0x40, 0xb0, 0, 0, cmd1, 2, 100);

    // read data to buffer and write to screen.
    uint8_t *frame = malloc(frame_size + margin);
    if (argc == 1) {
        if (frame_size == FRAMESIZE)
            argv[1] = "frame.dat";
        if (frame_size == FRAMESIZE5)
            argv[1] = "frame5.dat";
    }

    FILE *fp = fopen(argv[1], "rb");
    if (fp == NULL || frame_size != fread(frame + margin, 1, frame_size, fp)) {
        printf("Input file do not have enough data.\n"
               "Press any key to exit.\n");
        getchar();
        return -1;
    }
    fclose(fp);

    // write start frame command 0x2c.
    uint8_t cmd2[] = {0x00, 0x2c, frame_size, frame_size >> 8, frame_size >> 16, 0x00};

    // example: send two frames to screen.
    libusb_control_transfer(handle, 0x40, 0xb0, 0, 0, cmd2, 6, 100);
    libusb_bulk_transfer(handle, 0x02, frame, frame_size, NULL, 100);

    libusb_control_transfer(handle, 0x40, 0xb0, 0, 0, cmd2, 6, 100);
    libusb_bulk_transfer(handle, 0x02, frame, frame_size, NULL, 100);
    free(frame);



    // 3. now handle touch data.

    unsigned char cmd[128] = {0};
    struct touch *t = (struct touch *)cmd;
    int used = 0;

    printf("\n\nPlease tap on touch screen to test.\n");
    while (1) {
        int x1, x2, y1, y2, t1, t2;
        char map[][6] = {"PRESS", "HOVER", "DRAG"};
        argc = libusb_interrupt_transfer(handle, 0x81, cmd, 128, &used, -1);
        if (argc < 0)
            break;

        x1 = (((int)t->p[0].xh.x.h) << 8) + t->p[0].xl;
        y1 = (((int)t->p[0].yh.y.h) << 8) + t->p[0].yl;
        t1 = t->p[0].xh.x.f;
        x2 = (((int)t->p[1].xh.x.h) << 8) + t->p[1].xl;
        y2 = (((int)t->p[1].yh.y.h) << 8) + t->p[1].yl;
        t2 = t->p[1].xh.x.f;

        if (x2 == 4095 && y2 == 4095)
            printf("%d:%s (%d, %d)\n", t->p[0].yh.y.id, map[t1], x1, y1);
        else
            printf("%d:%s (%d, %d), %d:%s (%d, %d)\n",
                   t->p[0].yh.y.id, map[t1], x1, y1, t->p[1].yh.y.id, map[t2], x2, y2);
    }

    // close usb port.
    libusb_release_interface(handle, 0);
    libusb_close(handle);
    libusb_exit(context);
    return 0;
}

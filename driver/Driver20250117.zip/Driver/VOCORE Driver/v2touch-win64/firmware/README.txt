# Firmware Update


### Command Usage:

eeprom [r/w] [firmware name.bin]
example: eeprom.exe w FW210105-4IN3V3.bin


### Firmware Version:

- FW200502-4IN14V.bin: for driver board v05 or v07, 4inch screen.
- FW210105-4IN3V3.bin: for driver board v10, 4inch  screen.
- FW210426-5IN14V.bin: for driver board v07, 5inch screen.

note: driver board version can be find at bottom of the screen driver board.


### Console Upgrade Example:

Connect your screen to the computer, then run eeprom.exe:

```
Please choose your screen version:
        1. 4inch screen, driver board version v7a(or v05)
        2. 4inch screen, driver board version v10a
        3. 5inch screen, driver board version v07a
Your choose(1,2,3):2
Trying to upgrade your screen firmware...
................................
Done, press any key to exit.
```

After upgrade firmware, please reconnect the screen USB cable to make it valid.

note: do not power off your screen during upgrade.
